<template>
  <div class="hello">
    
   <vs-button vs-type="filled">Primary</vs-button>
  </div>
</template>
